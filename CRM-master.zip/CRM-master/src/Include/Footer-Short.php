                    </td>
                </tr>
            </table>

        </td>
    </tr>
</table>

</body>

</html>
<?php

// Turn OFF output buffering
                    ob_end_flush();

// Reset the Global Message
                    $_SESSION['sGlobalMessage'] = '';
