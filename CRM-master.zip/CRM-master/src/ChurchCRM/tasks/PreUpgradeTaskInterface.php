<?php

namespace ChurchCRM\Tasks;

interface PreUpgradeTaskInterface extends TaskInterface
{
}
