interface Calendar {
  Id: number;
  Name: string;
  AccessToken: string;
  BackgroundColor: string;
  ForegroundColor: string;
}

export default Calendar;
